-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 22 mai 2024 à 12:26
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_stagiaire`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE `commentaires` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `date_creation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commentaires`
--

INSERT INTO `commentaires` (`id`, `email`, `comment`, `date_creation`) VALUES
(2, 'ANW@gmail.com', 'je suis un ingénieur', '2024-05-22');

-- --------------------------------------------------------
--
-- Structure de la table `filiere`
--

CREATE TABLE `filiere` (
  `idFiliere` int(11) NOT NULL,
  `nomFiliere` varchar(20) NOT NULL,
  `niveau` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `filiere` (`idFiliere`, `nomFiliere`, `niveau`) VALUES
(1, 'Developpement Web', 'TS'),
(2, 'Génie logiciel', 'L'),
(3, 'Réseaux informatique', 'TS'),
(4, 'Conceptions', 'M'),
(5, 'Modélisation', 'CI');

CREATE TABLE `stagiaire` (
  `idStagiaire` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `civilite` varchar(1) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `idFiliere` int(6) NOT NULL,
  `date_inscription` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `stagiaire` (`idStagiaire`, `nom`, `prenom`, `Email`, `civilite`, `photo`, `idFiliere`, `date_inscription`) VALUES
(1, 'ANWAR', 'Bahida', 'ANW@gmail.com', 'M', 'WIN_20240320_21_21_28_Pro.jpg', 2, NULL),
(2, 'Bahida', 'Anwar', 'Anwar@gmail.com', 'M', 'WIN_20231029_20_27_57_Pro.jpg', 4, NULL),
(3, 'kezzo', 'Mustafa', 'Mustapha@gmail.com', 'M', 'WIN_20231029_20_27_57_Pro.jpg', 3, NULL),
(4, 'ALAWI', 'Ali', 'Ali@gmail.com', 'M', 'WIN_20231029_20_27_40_Pro.jpg', 5, NULL),
(5, 'ammari', 'ammari', 'ammari@gmail.com', 'F', 'IMAGE.jpg', 3, NULL),
(6, 'ammri', 'ammri', 'ammri@gmail.com', 'F', 'pro.jpeg', 2, NULL),
(7, 'AZE', 'AYOUB', 'Ayoub@gmail.com', 'M', 'WIN_20231029_20_27_40_Pro.jpg', 5, NULL),
(8, 'Lhabib', 'Naima', 'Naima@gmail.com', 'M', 'pro.jpeg', 4, NULL),
(9, 'Mouradi', 'Mourad', 'Mourad@gmail.com', 'M', 'WIN_20231029_20_27_40_Pro.jpg', 3, NULL);

CREATE TABLE `visiteur` (
  `iduser` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `etat` int(1) NOT NULL,
  `date_visite` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `visiteur` (`iduser`, `login`, `email`, `pwd`, `role`, `etat`, `date_visite`) VALUES
(1, 'Admin', 'ADMIN@GMAIL.COM', '123', 'ADMIN', 1, NULL),
(2, 'visiteur1', 'visiteur1@GMIAL.com', '123', 'VISITEUR', 1, NULL);

ALTER TABLE `commentaires`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `commentaires`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


