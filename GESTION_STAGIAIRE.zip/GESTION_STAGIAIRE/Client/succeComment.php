<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Succès</title>
    <link rel="stylesheet" href="styles.css">
    <script>
        // JavaScript pour animer le message de succès
        document.addEventListener("DOMContentLoaded", function() {
            // Appliquer une animation de fade-in au conteneur de succès
            const successContainer = document.querySelector(".success-container");
            successContainer.style.opacity = 0;
            setTimeout(() => {
                successContainer.style.transition = "opacity 1s";
                successContainer.style.opacity = 1;
            }, 50);

            // Rediriger l'utilisateur vers la page d'accueil après 5 secondes
            setTimeout(() => {
                window.location.href = "index.php";
            }, 2000);
        });
    </script>
</head>
<body>
    <div class="success-container">
        <h2>Envoi réussie!</h2>
        <p>Votre commentaire a été envoyer avec <font color='green'>succès.</font></p>
        <img src="images/succe.gif" alt="Succès">
    </div>
</body>
</html>
<style>
   /* Style global pour le corps de la page */
body {
    font-family: 'Roboto', sans-serif;
    background-color: #f0f2f5;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Conteneur principal */
.container, .success-container {
    background: #fff;
    padding: 40px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
    text-align: center;
    max-width: 500px;
    width: 100%;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.container:hover, .success-container:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

/* Titres */
h2 {
    color: #4CAF50;
    margin-bottom: 20px;
}

/* Formulaire */
form {
    display: flex;
    flex-direction: column;
}

label {
    margin-top: 10px;
    color: #333;
    font-weight: bold;
}

/* Champs de texte */
input[type="text"],
input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 12px;
    margin: 8px 0;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus {
    border-color: #4CAF50;
    outline: none;
}

/* Bouton de soumission */
input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

/* Conteneur de succès */
.success-container img {
    margin-top: 20px;
    width: 100px;
    height: auto;
    animation: bounce 2s infinite;
}

/* Animation de rebond pour l'image GIF */
@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
    }
    40% {
        transform: translateY(-20px);
    }
    60% {
        transform: translateY(-10px);
    }
}

/* Texte de succès */
.success-container p {
    color: #333;
    font-size: 18px;
    margin-top: 10px;
}

</style>