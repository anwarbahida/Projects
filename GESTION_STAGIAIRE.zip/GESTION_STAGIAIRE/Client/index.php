<!DOCTYPE html>
<html lang="fr">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre titre</title>
</head>
<body>
    <?php include "menu.php";   ?> 

    <main>
        <center><h1><font size='5'>Bienvenue : <font></h1><i class="fa-solid fa-face-smile icon"></i></center>
        <section id="content">
           
        </section>
        <section>
            <center><h1 >Description:</h1></center>
            <p id='paragraph'>
            Découvrez notre plateforme d'inscription de stagiaires, conçue pour simplifier la gestion des informations, le suivi de la progression et l'organisation des filieres de vos stagiaires. Dotée d'une interface conviviale et de fonctionnalités avancées, notre système facilite le processus d'inscription des stagiaires pour les entreprises.</p>
        </section>
        <script>
        // Ajout d'un effet de réaction au survol du paragraphe
        document.addEventListener("DOMContentLoaded", function() {
            const paragraph = document.getElementById("paragraph");
            if (paragraph) {
                paragraph.addEventListener("mouseover", function() {
                    paragraph.style.backgroundColor = "lightblue"; // Changement de couleur au survol
                });

                paragraph.addEventListener("mouseout", function() {
                    paragraph.style.backgroundColor = "lightgray"; // Rétablissement de la couleur d'origine
                });
            }
        });
        
        // Ajout d'un effet de survol sur les éléments de la liste
        document.addEventListener("DOMContentLoaded", function() {
            const listItems = document.querySelectorAll("ul li");
            listItems.forEach(item => {
                item.addEventListener("mouseover", function() {
                    item.style.color = "gray"; // Changement de couleur au survol
                });
                item.addEventListener("mouseout", function() {
                    item.style.color = "black"; // Rétablissement de la couleur d'origine
                });
            });
        });
    </script>
    </main>
    
       
    <footer>
        <center><img src="images/Dev.gif" ></center>
       <section><center><h1 >Motivation:</h1></center>
                <ul>
                    <li>étes vous intersé d'inscrire pour passer un stage PFE au moin 4 mois ?</li>
                    <li>vérifiez est ce que ton filier est inclu dans la liste des filiers demandés.</li>
                    <li>Si oui , qui ce que vous attendez ?</li>
                    <li><font color='Green' size='20px'><b><i><u>inscrire maintenant!!</u></i></b></font></li>
                </ul>  
        </section>
        <CEnter><a href='Au.php' ><img src="images/Inscriptions.gif" alt=""></a></CEnter>
        
        </footer>
    </body>
    <style>

        section {
            text-align: center;

        }
        h1 {
            font-size: 24px;
            font-weight: bold;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            margin-bottom: 10px;
            font-size: 20px;
            color: gray;
        }

        ul li:last-child {
            font-weight: bold;
            font-style: italic;
        }
            /* Styles pour un paragraphe spécifique */
        #content{
            margin-top:0.5cm;
            min-height: 550px;
            background:url('images/rejoins.gif') center;
        } 
        #cont{
            margin-top:0.5cm;
            min-height: 450px;
            background:url('images/aa.png') center;
        } 
        p{
            text-align:center;
            color:orange;
            font-family:'Arial';
            background: orange;
            color:green;
            font-size:20px;
            
        } 
        .icon {
            font-size: 4em; /* Changer la taille de l'icône */
            color:lightblue;
        }
        .icon:hover{
            
            color:yellow
        }
        h1{
            background-color:lightgreen;
            color:white;
            border-radius:6px;
        }
        h1:hover{
            
            background-color:green;
            color:light;
            border-radius:20px;
        }
        
        .box-container {
            display: flex;
            justify-content: space-between;
            margin-top:6cm;
        }

        /* Styles pour chaque boîte */
        .box {
            border: 1px solid #ccc;
            padding: 10px;
            width: 30%;
        }

        /* Styles pour les liens à l'intérieur des boîtes */
        .box a {
            text-decoration: none;
            color: #333;
            display: flex;
            align-items: center;
            margin-bottom: 5px;
            transition: color 0.3s ease; /* Transition fluide de la couleur */
        }

        /* Styles pour les icônes */
        .box a i {
            margin-right: 5px;
        }

        /* Effet de survol sur les liens */
        .box a:hover {
            color: #007bff; /* Changement de couleur au survol */
        }
        /* Styles de base pour la liste de navigation dans le header */
        #paragraph {
            font-size: 20px;
            line-height: 1.5;
            color: #333; /* Couleur du texte */
            background-color: #fff; /* Couleur de fond */
            padding: 20px; /* Espacement intérieur */
            border: 2px solid #ccc; /* Bordure */
            border-radius: 5px; /* Coins arrondis */
            box-shadow: 0 2px 10px green; /* Ombre */
        }
</style>