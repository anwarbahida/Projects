<?php
    require_once('../Admin/pages/connexiondb.php');
    
    $nomf=isset($_GET['nomF'])?$_GET['nomF']:"";
    $niveau=isset($_GET['niveau'])?$_GET['niveau']:"all";
    
    $size=isset($_GET['size'])?$_GET['size']:6;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
    
    if($niveau=="all"){
        $requete="select * from filiere
                where nomFiliere like '%$nomf%'
                limit $size
                offset $offset";
        
        $requeteCount="select count(*) countF from filiere
                where nomFiliere like '%$nomf%'";
    }else{
         $requete="select * from filiere
                where nomFiliere like '%$nomf%'
                and niveau='$niveau'
                limit $size
                offset $offset";
        
        $requeteCount="select count(*) countF from filiere
                where nomFiliere like '%$nomf%'
                and niveau='$niveau'";
    }

    $resultatF=$pdo->query($requete);

    $resultatCount=$pdo->query($requeteCount);
    $tabCount=$resultatCount->fetch();
    $nbrFiliere=$tabCount['countF'];
    $reste=$nbrFiliere % $size;   // % operateur modulo: le reste de la division 
                                 //euclidienne de $nbrFiliere par $size
    if($reste===0) //$nbrFiliere est un multiple de $size
        $nbrPage=$nbrFiliere/$size;   
    else
        $nbrPage=floor($nbrFiliere/$size)+1;  // floor : la partie entière d'un nombre décimal
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Filières demander</title>
        <link rel="stylesheet" type="text/css" href="Admin/css/font-awesome.min.css">
    </head>
    <body> 
    
    <?php 
    include "menu.php";   ?> 
    </header>
        <form action="Au.php">      
            <div class="panel panel-primary">
                <div class="panel-heading"><center>Liste des filières demander (<?php echo $nbrFiliere ?> Filières)</center></div>
                <div class="panel-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Id filière</th><th>Nom filière</th><th>Niveau</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php while($filiere=$resultatF->fetch()){ ?>
                                <tr>
                                    <td><?php echo $filiere['idFiliere'] ?> </td>
                                    <td><?php echo $filiere['nomFiliere'] ?> </td>
                                    <td><?php echo $filiere['niveau'] ?> </td> 
                                    
                                </tr>
                            <?PHP } ?>
                       </tbody>
                    </table>
                <div>
                    <ul class="pagination">
                        <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                            <li class="<?php if($i==$page) echo 'active' ?>"> 
                                <a href="Branch.php?page=<?php echo $i;?>&nomF=<?php echo $nomf ?>&niveau=<?php echo $niveau ?>">
                                <?php echo $i; ?>
                                </a> 
                             </li>
                        <?php } ?>
                    </ul>
                </div>
                </div>
            </div>
         </div>
         <div class='panel-body'>
           <center> Q : qualifiant <pre>  </pre>
            T : Technicien<pre>  </pre>
            TS : Technicien Spécialisé<pre>  </pre>
            L : Licence<pre>  </pre>
            M : Master<pre>  </pre>
            CI : cycle d'ingénieur<pre>  </pre></center> 
         </div>
        </form>
    <br><br><br><br><br><br><br><br><br><br>
    </body>
    
    <style>
        /* Style du conteneur */
        .container {
            width: 80%;
            margin: auto;
            
        }
        input.btn{
            background-color: #5cb85c;
            border-color: pink;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            font-size:20px;
            width:5cm;
            margin-left:12cm;

        }
        
        input.btn:hover{
            background-color: green;
            border-color: red;
            
        }
       
        .panel-success {
            margin-top: 60px;
            border: 1px solid #5cb85c;
            border-radius: 10px;
           
        }

        .panel-heading {
            background-color: #5cb85c;
            color: #fff;
            padding: 15px;
            margin:0 5cm 0 5cm;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            margin-top:4cm;

        }

        .panel-body {
            padding: 20px;
            margin:0 5cm 0 5cm;
            box-shadow: 0px 15px 40px green;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .btn-success {
            background-color: #5cb85c;
            border-color: #4cae4c;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-success:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
        }

        .pagination li {
            margin-right: 5px;
        }

        .pagination li a {
            text-decoration: none;
            color: #337ab7;
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .pagination li.active a {
            background-color: #337ab7;
            color: #fff;
        }

        .actions {
            display: flex;
            justify-content: center;
        }

        .actions a {
            color: #5cb85c;
            margin: 0 5px;
            transition: color 0.3s ease;
        }

        .actions a:hover {
            color: #4cae4c;
        }

        .box-container {
            display: flex;
            justify-content: space-between;
            margin-top:12cm;
        }

        .box {
            border: 1px solid #ccc;
            padding: 10px;
            width: 30%;
        }

        .box a {
            text-decoration: none;
            color: #333;
            display: flex;
            align-items: center;
            margin-bottom: 5px;
            transition: color 0.3s ease; 
        }

        .box a i {
            margin-right: 5px;
        }

        .box a:hover {
            color: #007bff; /* Changement de couleur au survol */
        }
        ul li {
            margin-bottom: 10px;
            font-size: 20px;
            color: gray;
        }

    </style>
</HTML>