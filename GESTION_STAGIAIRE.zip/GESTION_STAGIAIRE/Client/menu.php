<html>
    <header>
        <nav>
        <!-- Contenu de votre en-tête (menu de navigation, logo, etc.) -->
        <ul>
            <li><a href="index.php">Accueil</a></li>
            
            <li><a href="Branch.php">Filieres Demender</a></li>
            <li><a href="Au.php">S'inscrire</a></li>
            <li><a href="contact.php">Contacter Nous</a></li>
        </ul>
    </nav>
    </header>
</html>
<style>
     header ul {
            list-style: none; 
            padding: 0;
            margin: 0;
        }

        header ul li {
            display: inline-block; 
            margin-right: 20px; 
        }

        header ul li a {
            text-decoration: none; 
            color: #333; 
            font-weight: bold; 
            position: relative;
            transition: color 0.3s ease; 
        }

        header ul li a:hover {
            color: red; 
        }

        header ul li a::after {
            content: ''; /* Contenu vide */
            position: absolute; /* Position absolue */
            bottom: -2px; /* Décalage vers le bas */
            left: 0; /* Alignement à gauche */
            width: 100%; /* Largeur à 100% */
            height: 2px; /* Hauteur de la ligne */
            background-color: #007bff; /* Couleur de soulignement */
            transition: width 0.3s ease; /* Transition fluide de la largeur */
            transform: scaleX(0); /* Commence avec une largeur nulle */
        }

        header ul li a:hover::after {
            transform: scaleX(2); /* Agrandit la largeur au survol */
        }

        header {
            background-color: #007bff; /* Couleur de fond de l'en-tête */
            border-radius:20px;
        }

        header ul {
            list-style: none; 
            padding: 1%;
            margin: 0;
            display: flex; 
            justify-content: space-around;
            background-color: #007bff; 
            border-radius:20px;
        }

        header ul li {
            display: inline-block; 
        }

        header ul li a {
            text-decoration: none; 
            color: #fff; 
            padding: 10px; 
            border-radius:20px;
        }
        header ul li a:hover {
            background-color: #0056b3; 
        }
</style>