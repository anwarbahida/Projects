<?php 
    require_once("../Admin/pages/connexiondb.php");
    
        $email=isset($_POST['email'])?$_POST['email']:"";
        $comment=isset($_POST['comment'])?$_POST['comment']:"";
        

        $requet='INSERT INTO commentaires VALUES (null,?,?,NOW())';
        $statement=$pdo->prepare($requet);
        $statement->execute([$email,$comment]);
        header("location:succeComment.php ");
        exit();
?>