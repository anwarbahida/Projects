<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

<?php include "menu.php";?>
<section class="footer">
    <form action="insertionComment.php" method='POST'>
    <center><h1>Contacter Nous<h1></center>
        <div class="box-container">
        
            <div class="box">
                <a href="tel:1234567890"><i class="fas fa-phone"></i> +212-602 537 570</a><br>
                <a href="tel:1112223333"><i class="fas fa-phone"></i> +212-602 537 570</a><br>
                <a href="mailto:anwarbahida@gmail.com"><i class="fas fa-envelope"></i> anwar1bahida1@gmail.com</a><br>
                <a href="mailto:anwarbahida@gmail.com"><i class="fas fa-envelope"></i> anwar1bahida1@gmail.com</a><br>
                <a href="#"><i class="fas fa-map-marker-alt"></i>Errachidia _ Er-rich</a><br>
            </div> 
            <center><img src="images/contact.gif" alt=""></center> 
            <div class="box">
                <a href="https://www.facebook.com"><i class="fab fa-facebook-f"></i>facebook </a><br>
                <a href="https://www.twitter.com"><i class="fab fa-twitter"></i>twitter </a><br>
                <a href="https://www.instagram.com"><i class="fab fa-instagram"></i>instagram </a><br>
                <a href="https://www.linkedin.com"><i class="fab fa-linkedin"></i>linkedin </a><br>
                <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i>youtube </a><br>
            </div>
        </div>
        <br><br>
            <div class="center">
                <div class="label-container">
                    <textarea name="comment" rows="5" cols="33"placeholder=" "></textarea>
                    <label for="coment">Commentaires...</label>
                </div>
            </div>

            <div class="center">
                <div class="icon">
                    <input type="email" name='email' placeholder="Email@gmail.com" />
                </div>
            </div>
            <div class="center">
                <input type="submit" name="btn" value="Envoyer" />
            </div>
    </form>
    </section>
    <br><br><br><br><br><br><br><br><br><br><br><br>  

<style>
    img{
        width:90%;
        padding:10px;
        margin-right:0px;
    }
    .box-container {
        display: flex;
        justify-content: space-between;
        margin-top:6cm;
    }
    h1 {
        font-size: 24px;
        font-weight: bold;
        background-Color:lightgreen;
        color:white;
        border-radius:8px;
    }
    h1:hover {
        font-size: 24px;
        font-weight: bold;
        background-Color:green;
        color:white;
        border-radius:1px;
    }

    .box {
        border: 1px solid #ccc;
        padding: 10px;
        width: 30%;
    }

    .box a {
        text-decoration: none;
        color: #333;
        display: flex;
        align-items: center;
        margin-bottom: 5px;
        transition: color 0.3s ease; 
    }

    .box a i {
        margin-right: 5px;
    }

    .box a:hover {
        color: #007bff;
    }
    ul li {
        margin-bottom: 10px;
        font-size: 20px;
        color: gray;
    }
input[type="email"], input[type="submit"] {
            width: 100%;
            max-width: 400px;
            padding: 10px 15px;
            margin: 10px 0;
            border: 2px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            font-family: 'Arial', sans-serif;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="email"]:focus, input[type="submit"]:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.6);
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
            box-shadow: 0 0 8px rgba(0, 86, 179, 0.6);
        }

        .center {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 10px 0;
        }

        .icon {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .icon i {
            font-size: 2em;
            color: #007BFF;
        }

textarea {
    width: 100%;
    max-width: 600px;
    height: 150px;
    padding: 15px;
    border: 2px solid #ccc;
    border-radius: 10px;
    font-family: 'Helvetica Neue', Arial, sans-serif;
    font-size: 16px;
    color: #333;
    background-color: #f9f9f9;
    transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
    resize: vertical;
    line-height: 1.5;
}

textarea:focus {
    border-color: #007BFF;
    outline: none;
    background-color: #fff; 
    box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
}

.center {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 20px 0;
}

.label-container {
    position: relative;
    width: 100%;
    max-width: 600px;
}

.label-container label {
    position: absolute;
    top: 15px;
    left: 20px;
    color: #999;
    font-size: 16px;
    pointer-events: none;
    transition: all 0.3s ease;
}

textarea:focus + label,
textarea:not(:placeholder-shown) + label {
    top: -10px;
    left: 15px;
    font-size: 12px;
    color: #007BFF;
    background-color: #fff;
    padding: 0 5px;
}

textarea:focus::placeholder {
    color: transparent; 
}

</style>