<?php
    header("location:pages/Loading.php");
?>