<?php
   require_once('identifier.php');
    require_once('connexiondb.php');
    $idf=isset($_GET['idF'])?$_GET['idF']:0;
        $requete="select * from filiere where idFiliere=$idf";
        $resultat=$pdo->query($requete);
        $filiere=$resultat->fetch();
        $nomf=$filiere['nomFiliere'];
        $niveau=strtolower($filiere['niveau']);
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Edition d'une filière</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <style>
            .container {
                width: 80%;
                margin: auto;
            }
            .panel {
                margin-top: 60px;
                border-radius: 10px;
                box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
            }
            .panel-primary {
                border: 1px solid #337ab7;
            }
            .panel-heading {
                background-color: #337ab7;
                color: #fff;
                padding: 15px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                text-align: center;
                font-size: 24px;
            }
            .panel-body {
                padding: 20px;
                box-shadow: 0px 15px 60px green;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                font-size: 18px;
                color: #333;
            }
            .form-control {
                width: 90%;
                padding: 10px;
                border-radius: 5px;
                border: 1px solid #ddd;
                transition: border-color 0.3s ease;
            }
            #niveau {
                width: 93%;
            }
            .btn-success {
                background-color: #5cb85c;
                border: none;
                color: #fff;
                padding: 10px 20px;
                font-size: 18px;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }
            .btn-success:hover {
                background-color: green;
            }
        </style>
    </head>
    <body>
        <?php include("menu.php"); ?>
        <div class="container">
            <div class="panel panel-primary">
                <div class="panel-heading">Edition de la filière :</div>
                <div class="panel-body">
                    <form method="post" action="updateFiliere.php" class="form">
                        <div class="form-group">
                            <label for="niveau">id de la filière: <?php echo $idf ?></label>
                            <input type="hidden" name="idF" class="form-control" value="<?php echo $idf ?>"/>
                        </div>
                        <div class="form-group">
                            <label for="niveau">Nom de la filière:</label>
                            <input type="text" name="nomF" placeholder="Nom de la filière" class="form-control" value="<?php echo $nomf ?>"/>
                        </div>
                        <div class="form-group">
                            <label for="niveau">Niveau:</label><br>
                            <select name="niveau" class="form-control" id="niveau">
                                <option value="q" <?php if($niveau=="q") echo "selected" ?>>Qualification</option>
                                <option value="t" <?php if($niveau=="t") echo "selected" ?>>Technicien</option>
                                <option value="ts"<?php if($niveau=="ts") echo "selected" ?>>Technicien Spécialisé</option>
                                <option value="l" <?php if($niveau=="l") echo "selected" ?>>Licence</option>
                                <option value="m" <?php if($niveau=="m") echo "selected" ?>>Master</option>
                                <option value="ci" <?php if($niveau=="ci") echo "selected" ?>>Cycle d'ingenieur</option>

                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-save"></span> Enregistrer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>
