<?php
    require_once('identifier.php');
    require_once('connexiondb.php');

    $nom=isset($_POST['nom'])?$_POST['nom']:"";
    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";
    $Email=isset($_POST['email'])?$_POST['email']:"";
    $civilite=isset($_POST['civilite'])?$_POST['civilite']:"F";
    $idFiliere=isset($_POST['idFiliere'])?$_POST['idFiliere']:1;

    $nomPhoto=isset($_FILES['photo']['name'])?$_FILES['photo']['name']:"";
    $imageTemp=$_FILES['photo']['tmp_name'];
    move_uploaded_file($imageTemp,"../images/".$nomPhoto);
    
    if(!empty($nom)&&!empty($prenom)&&!empty($Email)&&!empty($civilite)&&!empty($idFiliere)&&!empty($nomPhoto)){
        $requete="INSERT into stagiaire(nom,prenom,Email,civilite,idFiliere,photo,date_inscription) values(?,?,?,?,?,?,NOW())";       
        $params=array($nom,$prenom,$Email,$civilite,$idFiliere,$nomPhoto);
        $resultat=$pdo->prepare($requete);
        $resultat->execute($params);
        header('location:stagiaires.php');
    }
    else{
        echo "<script type='text/javascript'>
            alert('Veuillez remplir tous les champs');
            setTimeout(function() {
                window.location.href = 'nouveauStagiaire.php';
            }, 10); // 3 seconds delay
          </script>";
    exit();
    }
    
?>