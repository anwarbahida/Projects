<?php
    require_once('identifier.php');
    require_once('connexiondb.php');

    $id = isset($_GET['id']) ? $_GET['id'] : 0;
    $requete = "select * from visiteur where iduser = $id";
    $resultat = $pdo->query($requete);
    $utilisateur = $resultat->fetch();
    $login = $utilisateur['login'];
    $email = $utilisateur['email'];
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Edition d'Admin</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <style>
            body {
                font-family: Arial, sans-serif;
            }
            .container {
                width: 80%;
                margin: 50px auto;
                padding: 20px;
                box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
                border-radius: 10px;
                background-color: #fff;
            }
            .panel {
                border-radius: 10px;
                overflow: hidden;
            }
            .panel-heading {
                background-color: #337ab7;
                color: #fff;
                padding: 20px;
                text-align: center;
                font-size: 24px;
            }
            .panel-body {
                padding: 20px;
                background-color: #f9f9f9;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                font-size: 18px;
                color: #333;
                display: block;
                margin-bottom: 10px;
            }
            .form-control {
                width: 100%;
                padding: 10px;
                border-radius: 5px;
                border: 1px solid #ddd;
                transition: border-color 0.3s ease;
            }
            .btn-success {
                background-color: #5cb85c;
                border: none;
                color: #fff;
                padding: 10px 20px;
                font-size: 18px;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s ease;
                display: block;
                width: 100%;
                max-width: 200px;
                margin: 20px auto 0;
            }
            .btn-success:hover {
                background-color: green;
            }
            form {
                background-color: #fff;
                padding: 20px;
                border: 2px solid gray;
                box-shadow: 0px 15px 60px green;
                border-radius: 10px;
            }
            input.inpt {
                width: calc(100% - 22px);
                padding: 10px;
                border-radius: 5px;
                border: 1px solid #ddd;
                margin-bottom: 20px;
                transition: background-color 0.3s ease;
            }
            input.inpt:hover {
                background-color: #333;
                color: #fff;
            }
            h2 {
                color: red;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <?php include("menu.php"); ?>
        <div class="container">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h2>Modification de vos informations :</h2>
                </div>
                <div class="panel-body">
                    <form method="post" action="updateUtilisateur.php" class="form">
                        <input type="hidden" name="iduser" class="form-control" value="<?php echo $id ?>"/>
                        <div class="form-group">
                            <label for="login">Login :</label>
                            <input type="text" name="login" placeholder="Login" class="inpt" value="<?php echo $login ?>"/>
                        </div>
                        <div class="form-group">
                            <label for="email">Email :</label>
                            <input type="email" name="email" placeholder="Email" class="inpt" value="<?php echo $email ?>" oninput="this.value = this.value.replace(/\s/g,'')"/>
                        </div>
                        <input type="submit" value="Enregistrer" class="btn btn-success">
                    </form>
                </div>
            </div>
        </div>
    </body>
</HTML>
