<?php

require_once("connexiondb.php");
include "fonctions.php";


//echo 'Nombre des  user1 :  '.rechercher_par_login('user1');
//echo 'Nombre des  user1@gmail.com :  '.rechercher_par_email('user1@gmail.com');
$validationErrors = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $login = $_POST['login'];
    $pwd1 = md5($_POST['pwd1']);
    $pwd2 = md5($_POST['pwd2']);
    $email = $_POST['email'];

    
    if (isset($login)) {
        $filtredLogin = filter_var($login, FILTER_SANITIZE_STRING);

        if (strlen($filtredLogin) < 4) {
            $validationErrors[] = "<center><font color='red'><b><h2>Erreur!!! Le login doit contenir au moins 4 caratères</h2></b></font></center>";
        }
    }

    if (isset($pwd1) && isset($pwd2)) {

        if (empty($pwd1)) {
            $validationErrors[] = "<center><font color='red'><b><h2>Erreur!!! Le mot ne doit pas etre vide</h2></b></font></center>";
        }

        if ($pwd1 !== $pwd2) {
            $validationErrors[] = "<center><font color='red'><b><h2>Erreur!!! les deux mot de passe ne sont pas identiques</h2></b></font></center>";

        }
    }

    if (isset($email)) {
        $filtredEmail = filter_var($login, FILTER_SANITIZE_EMAIL);

        if ($filtredEmail != true) {
            $validationErrors[] = "Erreur!!! Email  non valid";

        }
    }

    if (empty($validationErrors)) {
        if (rechercher_par_login($login) == 0 & rechercher_par_email($email) == 0) {
            $requete = $pdo->prepare("INSERT INTO visiteur(login,email,pwd,role,etat,date_visite) 
                                        VALUES(:plogin,:pemail,:ppwd,:prole,:petat,Now())");

            $requete->execute(array('plogin' => $login,
                'pemail' => $email,
                'ppwd' => $pwd1,
                'prole' => 'VISITEUR',
                'petat' => 0));
            
            $success_msg = "<center><font color='green'><b>Félicitation, votre compte est crée, mais temporairement inactif jusqu'a activation par l'admin</b></font></center>";
        } else {
            if (rechercher_par_login($login) > 0) {
                $validationErrors[] = "<center><font color='red'><b><h2>Désolé le login exsite deja</h2></b></font></center>";
            }
            if (rechercher_par_email($email) > 0) {
                $validationErrors[] = "<center><font color='red'><b><h2> Désolé cet email exsite deja</h2> </b></font></center>";
            }
        }

    }

}

?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <title> Nouvel Visiteur </title>
    
</head>
<body>

<div class="container col-md-6 col-md-offset-3">
    <h1 class="text-center"> Création d'un nouveau compte visiteur</h1>
    <form class="form" method="post">
        <div class="input-container">
            <input type="text"
                   required="required"
                   minlength="4"
                   title="Le login doit contenir au moins 4 caractères..."
                   name="login"
                   placeholder="Taper Username "
                   autocomplete="off"
                   class="form-control"
                   oninput="this.value = this.value.replace(/\s/g,'')"/>
        </div>
        <div class="input-container">
            <input type="password"
                   required="required"
                   minlength="3"
                   title="Le Mot de passe doit contenir au moins 3 caractères..."
                   name="pwd1"
                   placeholder="Taper Password"
                   autocomplete="new-password"
                   class="form-control"
                   oninput="this.value = this.value.replace(/\s/g,'')">
        </div>
        <div class="input-container">
            <input type="password"
                   required="required"
                   minlength="3"
                   name="pwd2"
                   placeholder="Retaper Password"
                   autocomplete="new-password"
                   class="form-control"
                   oninput="this.value = this.value.replace(/\s/g,'')">
        </div>
        <div class="input-container">

            <input type="email"
                   required="required"
                   name="email"
                   placeholder="Taper votre Email"
                   autocomplete="off"
                   class="form-control"
                   oninput="this.value = this.value.replace(/\s/g,'')">
        </div>
        <input type="submit" class="btn btn-primary" value="Enregistrer">
    </form>
    <br>
    <?php
    if (isset($validationErrors) && !empty($validationErrors)) {
        foreach ($validationErrors as $error) {
            echo '<div class="alert alert-danger">' . $error . '</div>';
        }
    }


    if (isset($success_msg) && !empty($success_msg)) {
        echo '<div class="alert alert-success">' . $success_msg . '</div>';

        header('refresh:3;url=login.php');
    }
    ?>
</div>
</body>
    <style>
        .container {
            margin-top: 50px;
        }
        h1 {
            text-align: center;
            color:green;
            margin-top:2cm;
        }
        .form {
            
            width: 100%;
            max-width: 400px;
            margin: auto;
            margin-top:2cm;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 15px 60px green;
        }
        .input-container {
            margin-bottom: 20px;
            margin-right:0.9cm;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color:lightgreen;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            background-color:lightgreen;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: green;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</html>



