<?php
    require_once('identifier.php');
    require_once("connexiondb.php");

    $nomf=isset($_GET['nomF'])?$_GET['nomF']:"";
    $niveau=isset($_GET['niveau'])?$_GET['niveau']:"all";

    $size=isset($_GET['size'])?$_GET['size']:6;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;

    if($niveau=="all"){
        $requete="select * from filiere
                where nomFiliere like '%$nomf%'
                limit $size
                offset $offset";

        $requeteCount="select count(*) countF from filiere
                where nomFiliere like '%$nomf%'";
    }else{
         $requete="select * from filiere
                where nomFiliere like '%$nomf%'
                and niveau='$niveau'
                limit $size
                offset $offset";

        $requeteCount="select count(*) countF from filiere
                where nomFiliere like '%$nomf%'
                and niveau='$niveau'";
    }

    $resultatF=$pdo->query($requete);

    $resultatCount=$pdo->query($requeteCount);
    $tabCount=$resultatCount->fetch();
    $nbrFiliere=$tabCount['countF'];
    $reste=$nbrFiliere % $size;
    if($reste===0)
        $nbrPage=$nbrFiliere/$size;
    else
        $nbrPage=floor($nbrFiliere/$size)+1;
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Gestion des filières</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    </head>
    <body>
        <?php include("menu.php"); ?>

        <div class="container">
            <div class="panel panel-success margetop60">
                <div class="panel-heading">Rechercher des filières</div>
                <div class="panel-body">
                    <form method="get" action="filieres.php" class="form-inline">
                        <div class="form-group">
                            <input type="text" name="nomF" 
                                   placeholder="Nom de la filière"
                                   class="form-control"
                                   value="<?php echo $nomf ?>"/>
                        </div>

                        <label for="niveau">Niveau de stagiaire:</label>
                        <select name="niveau" class="form-control" id="niveau"
                                onchange="this.form.submit()">
                            <option value="all" <?php if($niveau==="all") echo "selected" ?>>Tous les niveaux</option>
                            <option value="q"   <?php if($niveau==="q")   echo "selected" ?>>Qualification</option>
                            <option value="t"   <?php if($niveau==="t")   echo "selected" ?>>Technicien</option>
                            <option value="ts"  <?php if($niveau==="ts")  echo "selected" ?>>Technicien Spécialisé</option>
                            <option value="l"   <?php if($niveau==="l")   echo "selected" ?>>Licence</option>
                            <option value="m"   <?php if($niveau==="m")   echo "selected" ?>>Master</option> 
                            <option value="ci"  <?php if($niveau==="ci")  echo "selected" ?> >Cycle d'ingénieur</option>  
                        </select>

                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-search"></span>
                            Chercher...
                        </button> 

                        &nbsp;&nbsp;

                        <?php if ($_SESSION['user']['role']=='ADMIN') {?>
                            <a href="nouvelleFiliere.php">
                                <i class="fas fa-plus"></i>
                                Nouvelle filière
                            </a>
                        <?php } ?>                 
                    </form>
                </div>
            </div>

            <div class="panel panel-primary">
                <div class="panel-heading">Liste des filières (<?php echo $nbrFiliere ?> Filières)</div>
                <div class="panel-body">
                    <div class="filiere-list">
                        <div class="filiere-header">
                            <div>Numéro</div>
                            <div>Nom filière demandée</div>
                            <div>Niveau</div>
                            <?php if ($_SESSION['user']['role']== 'ADMIN') {?><div>Actions</div><?php }?>
                        </div>
                        <?php while($filiere=$resultatF->fetch()){ ?>
                            <div class="filiere-row">
                                <div><?php echo $filiere['idFiliere'] ?> </div>
                                <div><?php echo $filiere['nomFiliere'] ?> </div>
                                <div><?php echo $filiere['niveau'] ?> </div> 
                                <?php if ($_SESSION['user']['role']== 'ADMIN') {?>
                                    <div class="actions">
                                        <a href="editerFiliere.php?idF=<?php echo $filiere['idFiliere'] ?>">
                                            <i class="fa-solid fa-pencil-alt fa-lg"></i>
                                        </a>
                                        &nbsp;
                                        <a onclick="return confirm('Etes vous sur de vouloir supprimer la filière')"
                                            href="supprimerFiliere.php?idF=<?php echo $filiere['idFiliere'] ?>">
                                            <i class="fa-solid fa-trash-alt fa-lg"></i>
                                        </a>
                                    </div>
                                <?php }?>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="pagination-container">
                        <ul class="pagination">
                            <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                                <li class="<?php if($i==$page) echo 'active' ?>"> 
                                    <a href="filieres.php?page=<?php echo $i;?>&nomF=<?php echo $nomf ?>&niveau=<?php echo $niveau ?>">
                                        <?php echo $i; ?>
                                    </a> 
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <style>
        .fa-pencil-alt {
            color: lightblue;
        }
        .fa-pencil-alt:hover {
            color: green;
        }
        .fa-trash-alt {
            color: lightblue;
        }
        .fa-trash-alt:hover {
            color: red;
        }
        .container {
            width: 80%;
            margin: auto;
        }
        .panel-success {
            margin-top: 60px;
            border: 1px solid #5cb85c;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
        }
        .panel-heading {
            background-color: #5cb85c;
            color: #fff;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .panel-body {
            padding: 20px;
            box-shadow: 0px 15px 60px green;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-success {
            background-color: #5cb85c;
            border-color: #4cae4c;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .btn-success:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }
        .filiere-list {
            display: flex;
            flex-direction: column;
        }
        .filiere-header, .filiere-row {
            display: flex;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .filiere-header > div, .filiere-row > div {
            flex: 1;
            text-align: center;
        }
        .filiere-header {
            font-weight: bold;
        }
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
        }
        .pagination li {
            margin-right: 5px;
        }
        .pagination li a {
            text-decoration: none;
            color: #337ab7;
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .pagination li.active a {
            background-color: #337ab7;
            color: #fff;
        }
        .actions {
            display: flex;
            justify-content: center;
        }
        .actions a {
            color: #5cb85c;
            margin: 0 5px;
            transition: color 0.3s ease;
        }
        .actions a:hover {
            color: #4cae4c;
        }
        .form-control {
            border-radius: 6px;
            width: 5cm;
            height: 0.8cm;
            font-family: 'Times New Roman';
            background-color: black;
            font-size: 18px;
            color: white;
        }
        .form-control:hover {
            background-color: white;
            color: black;
            border-radius: 8px;
            height: 0.8cm;
            font-size: 18px;
            font-family: 'Times New Roman';
        }
        .fa-tags{
            color: #007bff;
        }
    </style>
</HTML>
