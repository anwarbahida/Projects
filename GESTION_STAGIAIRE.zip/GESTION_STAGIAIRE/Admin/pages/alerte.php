<?php
    require_once('identifier.php');
    
    $message=isset($_GET['message'])?$_GET['message']:"Erreur";
    
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Alerte</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    </head>
    <body>
        <center class='centre'><?php echo $message ?></center>               
        <?php include "filieres.php"; ?> 
    </body>
</HTML>
<style>
    .centre{
        font-size:20px;
        background-color:red;
        color:white;
    }
</style>