<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
    $idS = isset($_GET['idS']) ? $_GET['idS'] : 0;
    $requeteS = "select * from stagiaire where idStagiaire=$idS";
    $resultatS = $pdo->query($requeteS);
    $stagiaire = $resultatS->fetch();
    $nom = $stagiaire['nom'];
    $prenom = $stagiaire['prenom'];
    $Email = $stagiaire['Email'];
    $civilite = strtoupper($stagiaire['civilite']);
    $idFiliere = $stagiaire['idFiliere'];
    $nomPhoto = $stagiaire['photo'];
    $requeteF = "select * from filiere";
    $resultatF = $pdo->query($requeteF);
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Edition d'un stagiaire</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <style>
            .container {
                width: 80%;
                margin: auto;
            }
            .panel {
                margin-top: 60px;
                border-radius: 10px;
                box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
            }
            .panel-primary {
                border: 1px solid #337ab7;
            }
            .panel-heading {
                background-color: #337ab7;
                color: #fff;
                padding: 15px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                text-align: center;
                font-size: 24px;
            }
            .panel-body {
                padding: 20px;
                box-shadow: 0px 15px 60px green;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                font-size: 18px;
                color: #333;
            }
            .form-control {
                width: 90%;
                padding: 10px;
                border-radius: 5px;
                border: 1px solid #ddd;
                transition: border-color 0.3s ease;
            }
            .radio label {
                font-size: 18px;
                color: #333;
                margin-right: 15px;
            }
            .btn-success {
                background-color: #5cb85c;
                border: none;
                color: #fff;
                padding: 10px 20px;
                font-size: 18px;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }
            .btn-success:hover {
                background-color: green;
            }
            .form-label-fixed {
                display: inline-block;
                width: 120px; /* Set this width according to your design */
                font-weight: bold;
                margin-right: 10px; /* Add some space between the label and the input */
            }

            .uniform-input {
                width: calc(100% - 140px); /* Adjust based on label width and margin */
                max-width: 400px; /* Adjust this value as needed */
                display: inline-block;
                box-sizing: border-box; /* Include padding and border in the element's total width and height */
            }

            .form-group {
                margin-bottom: 15px; /* Add some space between form groups */
            }

            .form-check-inline {
                margin-right: 10px; /* Space between radio buttons */
            }
        </style>
    </head>
    <body>
        <?php include("menu.php"); ?>
        <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Edition du stagiaire :</div>
        <div class="panel-body">
            <form method="post" action="updateStagiaire.php" class="form" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="idS" class="form-label-fixed">id du stagiaire:</label>
                    <input type="hidden" name="idS" class="form-control uniform-input" value="<?php echo $idS ?>"/><?php echo $idS ?>
                    
                </div>
                <div class="form-group">
                    <label for="nom" class="form-label-fixed">Nom :</label>
                    <input type="text" name="nom" placeholder="Nom" class="form-control uniform-input" value="<?php echo $nom ?>"/>
                </div>
                <div class="form-group">
                    <label for="prenom" class="form-label-fixed">Prénom :</label>
                    <input type="text" name="prenom" placeholder="Prénom" class="form-control uniform-input" value="<?php echo $prenom ?>"/>
                </div>
                <div class="form-group">
                    <label for="email" class="form-label-fixed">Email :</label>
                    <input type="email" name="email" placeholder="Email" class="form-control uniform-input" value="<?php echo $Email ?>" oninput="this.value = this.value.replace(/\s/g,'')"/>
                </div>
                <div class="form-group">
                    <label for="civilite" class="form-label-fixed">Civilité :</label>
                    <div class="form-check form-check-inline">
                        <label class="form-check-label"><input type="radio" name="civilite" value="F" class="form-check-input" <?php if($civilite==="F") echo "checked" ?>/> F</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <label class="form-check-label"><input type="radio" name="civilite" value="M" class="form-check-input" <?php if($civilite==="M") echo "checked" ?>/> M</label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="idFiliere" class="form-label-fixed">Filière:</label>
                    <select name="idFiliere" class="form-control uniform-input" id="idFiliere">
                        <?php while($filiere=$resultatF->fetch()) { ?>
                            <option value="<?php echo $filiere['idFiliere'] ?>" <?php if($idFiliere===$filiere['idFiliere']) echo "selected" ?>><?php echo $filiere['nomFiliere'] ?></option>
                        <?php }?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="photo" class="form-label-fixed">CV :</label>
                    <input type="file" name="photo" class="uniform-input"/>
                </div>
                <button type="submit" class="btn btn-success">
                    <span class="glyphicon glyphicon-save"></span> Enregistrer
                </button>
            </form>
        </div>
    </div>
</div>

<style>
    
</style>

    </body>
</HTML>
