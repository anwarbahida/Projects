<center><img src="../images/lg.gif" ></center>
<body>
<script>
    var delai = 2* 1000;
    function redirection() {
        window.location.href = "stagiaires.php"; 
    }
    var timer = setTimeout(redirection, delai);
</script>
</body>

<style>
    img{
       margin-top:4cm;
    }
</style>