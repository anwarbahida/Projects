<?php
        session_start();
        if(isset($_SESSION['user']) ){
            
            if($_SESSION['user']['role']=='ADMIN'){
               
                require_once('connexiondb.php');
                
                $idS=isset($_GET['idS'])?$_GET['idS']:0;
                $if(!empty($idS)){
                    $requete="delete from stagiaire where idStagiaire=?";
                    
                    $params=array($idS);
                    
                    $resultat=$pdo->prepare($requete);
                    
                    $resultat->execute($params);
                    
                    header('location:stagiaires.php'); 
                }
            }
        }else {
                header('location:login.php');
        }
?>