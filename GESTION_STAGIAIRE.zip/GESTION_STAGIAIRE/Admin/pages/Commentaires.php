<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
    $requet='SELECT * FROM commentaires ';
    $statemant=$pdo->query($requet);
?>

<html>
    <head>
        <title>Commentaires</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    </head>
    <body>
        <?php include "menu.php";?>
        <br><br><br>
        <div class='container'>
            <div class='panel'>
                <div class='panel-heading'>
                      <center><font size='6px'>Commentaires</font></center>
                </div>
                <div class='panel-body'>
                    <table>
                        <thead>
                            <tr>
                                <th>Emails</th><th>Commentaires</th><th>date</th><th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($resultat=$statemant->fetch()){?>
                                <tr>
                                    <td><?php echo $resultat['email']?></td>
                                    <td><?php echo $resultat['comment']?></td>
                                    <td><?php echo $resultat['date_creation']?></td>
                                    <td>
                                        <a onclick="return confirm('Etes vous sur de vouloir supprimer ce visiteur')"
                                            href="SupprimerCommentaire.php?mail=<?php echo $resultat['email'] ?>">
                                            <i class="fa-solid fa-trash-alt fa-lg"></i>
                                        </a>
                                    </td>
                                    <?php } ?>
                                </tr>
                        </tbody>
                    </table>
                    
                </div>
                
            </div>
        </div>
    </body>
    
</html>
<style>

.container {
    width: 80%;
    margin: 20px auto;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.panel {
    margin: 20px;
}

.panel-heading {
            background-color: #5cb85c;
            color: #fff;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

.panel-body {
    padding: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th, table td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
}

table th {
    background-color: #f2f2f2;
    text-align: left;
}

table td {
    text-align: left;
}

form {
    margin-top: 20px;
}

.fa-comment {
    color: #007bff;
}

</style>