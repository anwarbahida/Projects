<?php
session_start();
if (isset($_SESSION['erreurLogin']))
    $erreurLogin = $_SESSION['erreurLogin'];
else {
    $erreurLogin = "";
}
session_destroy();
?>
<!DOCTYPE HTML>
<HTML>
<head>
    <meta charset="utf-8">
    <title>Se connecter</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            padding-top: 50px;
        }

        .panel {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .panel-primary {
            border-color: #337ab7;
        }

        .panel-body {
            padding: 30px;
            
        }

        .form {
            margin-top: 20px;
        }

        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-size: 18px;
            margin-bottom: 5px;
        }

        .form-group input {
            width: calc(100% - 30px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }

        .form-group .show-new-pwd {
            margin-left: -30px;
            cursor: pointer;
        }

        .form-group .show-new-pwd:hover {
            color: black;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        a {
            color: #337ab7;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        h2 {
            text-align: center;
            color: green;
            margin-bottom: 20px;
        }

        @media only screen and (max-width: 768px) {
            .container {
                width: 95%;
            }

            .panel-body {
                padding: 10px;
            }

            .form-group input {
                width: calc(100% - 20px);
                margin-right: 5px;
            }

            input[type="submit"] {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <BR></BR>
<div class="container">
    <div class="panel panel-primary">
        <div class="panel-body">
            <form method="post" action="seConnecter.php" class="form">
                <?php if (!empty($erreurLogin)) { ?>
                    <div class="alert alert-danger">
                        <?php echo $erreurLogin ?>
                    </div>
                <?php } ?>
                <h2><b>S'Authentifier</b></h2>
                <div class="form-group">
                    <label for="login"><b>Username</b></label>
                    <input type="text" id="login" name="login" placeholder="username" autocomplete="off" oninput="this.value = this.value.replace(/\s/g,'')"/>
                </div>
                <div class="form-group">
                    <label for="pwd"><b>Password</b></label>
                    <div style="position: relative;">
                        <input type="password" id="pwd" name="pwd" placeholder="Password" oninput="this.value = this.value.replace(/\s/g,'')"/>
                        <i class="fa fa-eye fa-2x show-new-pwd" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%);"></i>
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" value="Login"/>
                </div>
                <div class="form-group" style="text-align: center;">
                    <span><b>Vous n'avez pas un compte ?</b></span><br> <a href="nouvelUtilisateur.php"><b>Créer un compte</b></a>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var showPwdIcons = document.querySelectorAll(".show-new-pwd");

        showPwdIcons.forEach(function(icon) {
            icon.addEventListener("click", function() {
                var pwdInput = icon.previousElementSibling;
                if (pwdInput.type === "password") {
                    pwdInput.type = "text";
                    icon.classList.remove("fa-eye");
                    icon.classList.add("fa-eye-slash");
                } else {
                    pwdInput.type = "password";
                    icon.classList.remove("fa-eye-slash");
                    icon.classList.add("fa-eye");
                }
                // Empêcher le comportement par défaut du clic sur l'icône
                event.preventDefault();
            });
        });
    });
</script>
</body>
</HTML>
