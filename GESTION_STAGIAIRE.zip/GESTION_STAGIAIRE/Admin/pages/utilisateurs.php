<?php
    require_once('role.php');
    require_once("connexiondb.php");
    $login=isset($_GET['login'])?$_GET['login']:"";
    
    $size=isset($_GET['size'])?$_GET['size']:3;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
   
    $requeteUser="select * from visiteur where login like '%$login%'";
    $requeteCount="select count(*) countUser from visiteur";
    
    $resultatUser=$pdo->query($requeteUser);
    $resultatCount=$pdo->query($requeteCount);

    $tabCount=$resultatCount->fetch();
    $nbrUser=$tabCount['countUser'];
    $reste=$nbrUser % $size;   
    if($reste==0) 
        $nbrPage=$nbrUser/$size;   
    else
        $nbrPage=floor($nbrUser/$size)+1;  
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Gestion des Visiteurs </title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    </head>
    <body>
  
        <?php include("menu.php"); ?>
        
        <div class="container">
            <div class="panel panel-success margetop60">
				<div class="panel-heading">Rechercher des Visiteurs</div>
				<div class="panel-body">
					<form method="get" action="utilisateurs.php" class="form-inline">
						<div class="form-group">
                            <input type="text" name="login" 
                                   placeholder="Login"
                                   class="form-control"
                                   value="<?php echo $login ?>"/>
                        </div>
				        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-search"></span>
                            Chercher...
                        </button> 
					</form>
				</div>
			</div>
            
            <div class="panel panel-primary">
                <div class="panel-heading">Liste des Visiteurs (<?php echo $nbrUser ?> Visiteurs)</div>
                <div class="panel-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>login</th> <th>Email</th> <th>Etat</th><th> date </th> <th>Actions</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php while($user=$resultatUser->fetch()){ ?>
                                <tr class="<?php echo $user['etat']==1?'success':'danger'?>">
                                <?php if(!($user['role']=='ADMIN')){?>
                                    <td><?php echo $user['login'] ?> </td>
                                    <td><?php echo $user['email'] ?> </td>
                                    <td><?php if($user['etat']=='0'){echo"<b><font color='red'>Visiteur désactiver</font></b>";}
                                    if($user['etat']=='1'){echo"<b><font color='green'>Visiteur Activer</font></b>";} ?> </td> 
                                    <td> <?php echo $user['date_visite'] ?> </td> 
                                   <td>
                                        <a href="editerUtilisateur.php?idUser=<?php echo $user['iduser'] ?>">
                                        <i class="fa-solid fa-pencil-alt fa-lg"></i>
                                        </a>
                                        &nbsp;&nbsp;
                                        <a onclick="return confirm('Etes vous sur de vouloir supprimer ce visiteur')"
                                            href="supprimerUtilisateur.php?idUser=<?php echo $user['iduser'] ?>">
                                            <i class="fa-solid fa-trash-alt fa-lg"></i>
                                        </a>
                                        
                                        <a href="activerUtilisateur.php?idUser=<?php echo $user['iduser'] ?>&etat=<?php echo $user['etat']  ?>">  
                                                <?php  
                                                    if($user['etat']==1)
                                                        echo '<i class="fa-solid fa-thumbs-up fa-lg"></i>';
                                                    else 
                                                        echo '<i class="fa-solid fa-thumbs-down fa-lg"></i>';
                                                ?>
                                            </a>
                                        </td>      
                                        <?php } ?> 
                                </tr>
                             <?php } ?>
                        </tbody>
                    </table>
                <BR>
                </div>
            </div>
        </div>
        <BR><BR><BR><BR><BR><BR><BR>
    </body>
    <style>
        /* Style du conteneur */
        .fa-pencil-alt{
            color:lightblue;
        }
        .fa-pencil-alt:hover{
            color:green;
        }
        .fa-trash-alt{
            color:lightblue;
        }
        .fa-trash-alt:hover{
            color:red;
        }
        .fa-thumbs-up{
            padding:0.2cm;
            margin-left:0.2cm;
            color:lightblue;
        }
        .fa-thumbs-down{
            padding:0.2cm;
            margin-left:0.2cm;
            color:lightblue;
        }
        .fa-thumbs-up:hover{
            color:green;
        }
        .fa-thumbs-down:hover{
            color:red;
        }

        .container {
            width: 80%;
            margin: auto;
        }

        /* Style du panneau de recherche */
        .panel-success {
            margin-top: 60px;
            border: 1px solid #5cb85c;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
        }

        /* Style de l'en-tête du panneau */
        .panel-heading {
            background-color: #5cb85c;
            color: #fff;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        /* Style du corps du panneau */
        .panel-body {
            padding: 20px;
            box-shadow:0px 15px 60px green;
        }

        /* Style des éléments du formulaire */
        .form-group {
            margin-bottom: 20px;
        }

        /* Style des boutons */
        .btn-success {
            background-color: #5cb85c;
            border-color: #4cae4c;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        /* Style des boutons lors du survol */
        .btn-success:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }

        /* Style de la table */
        .table {
            width: 100%;
            border-collapse: collapse;
        }

        /* Style des lignes de tableau */
        .table th,
        .table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        /* Style de la pagination */
        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
        }

        .pagination li {
            margin-right: 5px;
        }

        .pagination li a {
            text-decoration: none;
            color: #337ab7;
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .pagination li.active a {
            background-color: #337ab7;
            color: #fff;
        }
        .actions {
            display: flex;
            justify-content: center;
        }

        /* Style des liens d'action */
        .actions a {
            color: #5cb85c;
            margin: 0 5px;
            transition: color 0.3s ease;
        }

        /* Style des liens d'action lors du survol */
        .actions a:hover {
            color: #4cae4c;
        }
        .form-control{
            border-radius:6px;
            width: 5cm;
            height:0.8cm;
            font-family:'Time New Roman';
            background-color:black;
            font-size:18px;
            color:white;
        }

        .form-control:hover{
            background-color:white;
            color:black;
            border-radius:8px;
            height:0.8cm;
            font-size:18px;
            font-family:'Time New Roman';
        }
        @media only screen and (max-width: 768px) {
            .container {
                width: 95%; /* Réduire la largeur du conteneur */
            }
            .panel-body {
                padding: 10px; /* Réduire l'espacement dans le corps du panneau */
            }
            .table th,
            .table td {
                padding: 8px; /* Réduire le rembourrage dans les cellules du tableau */
            }
            .btn-success {
                padding: 8px 16px; /* Réduire la taille des boutons */
            }
        }
        .fa-users{
            color: #007bff;
	    }

    </style>
</HTML>
