<?php
    session_start();
    
        require('connexiondb.php');
        $email = isset($_GET['mail']) ? $_GET['mail'] : '';

        if(!empty($email)){
            $requete = "DELETE FROM commentaires WHERE email = ?";
            $params = array($email);
            $resultat = $pdo->prepare($requete);
            $resultat->execute($params);

            header('location:Commentaires.php');  
        } 
    
?>
