<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
   
    $requeteF="select * from filiere";
    $resultatF=$pdo->query($requeteF);

?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Nouveau stagiaire</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <script type="text/javascript">
        function validateForm() {
            var nom = document.getElementById('nom').value;
            var prenom = document.getElementById('prenom').value;
            var email = document.getElementById('email').value;
            var civilite = document.getElementById('civilite').value;
            var idFiliere = document.getElementById('idFiliere').value;
            var photo = document.getElementById('photo').value;

            if(nom == "" || prenom == "" || email == "" || civilite == "" || idFiliere == "" || photo == "") {
                alert("Veuillez remplir tous les champs");
                return false;
            }
            return true;
        }
    </script>
    </head>
    <body>
        <?php include("menu.php"); ?>
        
        <div class="container">
                       
             <div class="panel panel-primary margetop60">
                <center><div class="panel-heading">Les infos du nouveau stagiaire :</div></center>
                <div class="panel-body">
                    <form method="post" action="insertStagiaire.php" class="form"  enctype="multipart/form-data">
						<center><table>
                            <br><br><br>
                            <tr>
                                <td>
                                    <label for="nom">Nom <br><br></label>
                                </td>
                                <td>:<br><br></td>
                                <td><input class="inpt" type="text" name="nom" placeholder="Nom" /><br><br></td>
                            </tr>
                            <tr>
                                <td><label for="prenom">Prénom </label><br><br></td>
                                <td>:<br><br></td>
                                <td><input class="inpt"  type="text" name="prenom" placeholder="Prénom" /><br><br></td>
                            </tr>
                            <tr>
                                <td><label for="prenom">Email </label><br><br></td>
                                <td>:<br><br></td>
                                <td><input class="inpt"  type="email" name="email" placeholder="Email" oninput="this.value = this.value.replace(/\s/g,'')"/><br><br></td>
                            </tr
                            <tr>
                                <td><label for="civilite">Civilité </label><br></td>
                                <td>:<br></td>
                                <td><br><div class="radio">
                                <label><input type="radio" name="civilite" value="F" checked/> F </label>
                                <label><input type="radio" name="civilite" value="M"/> M </label>
                                </div>
                                <br></td>
                            </tr>
                            <tr>
                                <td><label for="idFiliere">Filière</label><br><br></td>
                                <td>:<br><br></td>
                                <td><select name="idFiliere" class="form-control" id="idFiliere">
                                        <?php while($filiere=$resultatF->fetch()) { ?>
                                            <option value="<?php echo $filiere['idFiliere'] ?>"> 
                                                <?php echo $filiere['nomFiliere'] ?>
                                            </option>
                                        <?php }?>
                                    </select>
                                    <br><br></td>
                            </tr>
                            <tr>
                                <td><label for="photo">CV</label><i><b>(Format d'image : jpg,ong,jpeg...) </b></i><br><br></td>
                                <td>:<br><br></td>
                                <td> <input type="file" name="photo" id="cv" /><br><br></td>
                            </tr>

                            <tr>
                                <td><br><br></td>
                                <td><input type="submit" value="Enregistrer" class="btn btn-success"><br><br></td>
                            </tr>
                        </table> 
                        </center>
					</form>
                </div>
            </div>   
        </div>      
    </body>
    <style>
        #idFiliere{
            border: 2px solid #ccc;
            padding:5px;
            border-radius:6px;
            width:4.655cm;
            
        }
        #cv{
            border: 2px solid #ccc;
            padding:5px;
            border-radius:6px;
            width:5cm;
        }
        table{
            border: 1px solid #ccc;
            padding:25px;
            box-shadow:0px 15px 60px green;
            
        }
        .panel-heading {
            background-color: green;
            color: White;
            padding: 10px;
            margin-top:1cm;
            width:40%;
            font-size:20px;
        }
        /* Style des boutons */
        .btn-success {
            background-color: #5cb85c;
            border-color: pink;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            font-size:20px;
            width:5cm;

        }

        .btn-success:hover {
            background-color: green;
            border-color: red;
            
        }

        table tr {
            height: 65px;
        }
        label {
            font-weight: bold;
            font-size:25px;
        }
        input.inpt{
        padding:0.2cm;
        border-radius:5px;
        color:black;
        }
        input.inpt:hover{
            padding:0.2cm;
            border-radius:5px;
            background-color:black;
            color:white;
        }

        .panel-heading {
            text-align: center;
        }

    </style>
</HTML>
