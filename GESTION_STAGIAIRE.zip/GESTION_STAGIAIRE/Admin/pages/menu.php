<?php
    //require_once('identifier.php');
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

<nav class="navbar navbar-inverse navbar-fixed-top">

	<div class="container-fluid">
	
		<div class="navbar-header">
		
			<a href="#" class="navbar-brand">Gestion des stagiaires</a>
			
		</div>
		
		<ul class="nav navbar-nav">
					
			<li><a href="stagiaires.php">
                    <i class="fa fa-vcard"></i>
                      Stagiaires
                </a>
            </li>
			<br>
			<li><a href="filieres.php">
                    <i class="fa fa-tags"></i>
                     Filières
                </a>
            </li>
			<br>
			<?php if ($_SESSION['user']['role']=='ADMIN') {?>
					
				<li><a href="Utilisateurs.php">
                        <i class="fa fa-users"></i>
                        Visiteur
                    </a>
                </li>
				<br>
				<li><a href="Commentaires.php">
				        <i class="fas fa-comment"></i>
                        Commentaires
                    </a>
                </li>
				
			<?php }?>
			
		</ul>
		
		
		<ul class="nav navbar-nav navbar-right">
					
			<li>
				<a href="editerUserLogin.php?id=<?php echo $_SESSION['user']['iduser'] ?>">
                    
					<i class="fa-solid fa-user"></i>
					<?php echo  ' '.$_SESSION['user']['login']?>
				</a> 
			</li>
			
			<li>
				<a href="seDeconnecter.php">
                    <i class="fa fa-sign-out"></i>
					&nbsp Se déconnecter
				</a>
			</li>
							
		</ul>
		
	</div>
</nav>
<style>
	.navbar {
    background-color: #333;
    border: none; 
	}
	.navbar-nav li a {
		color: gray; 
		padding: 5px; 
		font-size: 20px; 
		text-decoration: none; 
	}

	.navbar-nav li a:hover {
		background-color: black;
		color: white;
	}
    .navbar-header{
		display:flex;
		justify-content:center;
		text-align:center;
	}
	.navbar-brand {
		color: white; 
		font-size: 24px;
		margin-top:1.55cm;
		text-decoration: none;
		border-radius:8px;
		display: flex;
		justify-content:center;
		text-align:center;
		box-shadow:0px 14px 60px aqua ;
		background-color:#104f4f9e;	
	}

	.navbar-right .fa-user {
		font-size: 18px; 
		margin-right: 51px;
		margin-left:14px;
		color:lightgreen; 
		margin-top:0.8cm;
	}

	.navbar-right .fa-sign-out {
		font-size: 20px;
		margin-right: 20px;
		color:red; 
	}
	.container-fluid {
		display:flex; 
		justify-content: space-around; 
	}

	.navbar-header,.navbar-right {
	    justify-content: space-between; 
		display:block ; 
	}

	.navbar-nav li {
		margin: 0 10px; 
	}
	.navbar-right .fa {
		margin-right: 5px;
		margin-top:0.4cm; 
		padding:0.4cm;
	}
	.navbar-nav {
    list-style-type: none;
	margin-top:1cm;
    }
	.navbar-nav li {
    margin-right: 20px; 
    }
	
</style>