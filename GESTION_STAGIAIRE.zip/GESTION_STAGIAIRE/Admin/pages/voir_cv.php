<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
        }
        .download-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #007BFF;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .download-button:hover {
            background-color: #0056b3;
        }

        /* Styles spécifiques pour les écrans de petite taille (smartphones) */
        @media only screen and (max-width: 600px) {
            .download-button {
                font-size: 14px;
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['image'])) {
            $dossierImages = '../images/';
            $image = $_GET['image'];
            $imagePath = $dossierImages . $image;

            if (file_exists($imagePath)) {
                echo '<img src="' . $imagePath . '" alt="Image agrandie">';
                echo '<br><a href="' . $imagePath . '" download="' . $image . '" class="download-button"><i class="fas fa-download"></i> Télécharger cv</a>';
            } else {
                echo '<script>alert("L\'image de cv demandée n\'existe pas.")</script>';
            }
        } else {
            echo '<script>alert("Aucune image de cv spécifiée.")</script>';
        }
        ?>
    </div>
</body>
</html>

