<?php 
    require_once('identifier.php');
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    </head>
    <body>
        <?php include("menu.php"); ?>
        
        <div class="container">
                       
             <div class="panel panel-primary margetop60">
                <div class="panel-heading">Veuillez saisir les données de la nouvelle filère</div>
                <div class="panel-body">
                    <form method="post" action="insertFiliere.php" class="form">
						
                        <div class="form-group">
                             <label for="niveau">Nom de la nouvelle filière :</label>
                            <input type="text" name="nomF" 
                                   placeholder="Nom de la filière"
                                   class="form-control"/>
                        </div>
                        
                        <div class="form-group">
                            <label for="niveau">Niveau de stagiaire:</label><br>
				            <select name="niveau" class="form-control" id="niveau">
                                <option value="q">Qualification</option>
                                <option value="t">Technicien</option>
                                <option value="ts" selected>Technicien Spécialisé</option>
                                <option value="l">Licence</option>
                                <option value="m">Master</option>
                                <option value="ci">Cycle d'ingénieur</option>  
				            </select>
                        </div>
                        
				        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-save"></span>
                            Enregistrer
                        </button> 
                      
					</form>
                </div>
            </div>
            
        </div>      
    </body>
    <style>
        .container {
            width: 80%;
            margin: auto;
        }
        .panel-heading {
            background-color:#5cb85c;
            color: #fff;
            padding: 15px;
            margin:0 6cm 0 6cm;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            margin-top:3cm;
        }

        .panel-body {
            margin:0 6cm 0 6cm;
            padding: 20px;
            box-shadow:0px 15px 60px green;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .btn-success {
            background-color: #5cb85c;
            border-color: #4cae4c;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-success:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }

        .form-control {
            width: 90%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            transition: border-color 0.3s ease;
        }
        #niveau{
            width:93%;
        }
        .form-control:focus {
            border-color: #337ab7;
        }

        .form-control option {
            padding: 10px;
        }

        .form-control option:checked {
            background-color: #337ab7;
            color: #fff;
        }

        label {
            font-weight: bold;
        }

        .glyphicon {
            margin-right: 5px;
        }

    </style>
</HTML>