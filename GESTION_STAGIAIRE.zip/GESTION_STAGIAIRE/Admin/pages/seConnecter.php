<?php
    session_start();
    require_once('connexiondb.php');
    
    $login=isset($_POST['login'])?$_POST['login']:"";
    
    $pwd= md5($_POST['pwd']) ;
   
        $requete="select *
                    from visiteur where login='$login' 
                    and pwd='$pwd'";
        
        $resultat=$pdo->query($requete);
        if($user=$resultat->fetch()){
        
            if($user['etat']==1){
                
                $_SESSION['user']=$user;
                header('location:../index1.php');
                
            }else{
                
                $_SESSION['erreurLogin']="<center><font color='red'><b><h2><strong>Erreur!!</strong> Votre compte est désactivé.<br> Veuillez contacter l'admin</h2></b></font></center>";
                header('location:login.php');
            }
        }
    else {
        $_SESSION['erreurLogin']="<center><font color='red'><b><h2><strong>Veuillez Entrer username et le password correctement</h2></b></font></center>";
        header('location:login.php');
    }

?>
