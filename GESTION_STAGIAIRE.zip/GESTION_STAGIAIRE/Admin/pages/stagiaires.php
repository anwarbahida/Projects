<?php
    require_once('identifier.php');
    require_once("connexiondb.php");
  
    $nomPrenom=isset($_GET['nomPrenom'])?$_GET['nomPrenom']:"";
    $idfiliere=isset($_GET['idfiliere'])?$_GET['idfiliere']:0;
    $size=isset($_GET['size'])?$_GET['size']:5;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;

    $requeteFiliere="select * from filiere";

    if($idfiliere==0){
        $requeteStagiaire="select idStagiaire,nom,prenom,Email,nomFiliere,photo,civilite,date_inscription 
                from filiere as f,stagiaire as s
                where f.idFiliere=s.idFiliere
                and (nom like '%$nomPrenom%' or prenom like '%$nomPrenom%')
                order by idStagiaire
                limit $size
                offset $offset";
        
        $requeteCount="select count(*) countS from stagiaire
                where nom like '%$nomPrenom%' or prenom like '%$nomPrenom%'";
    } else {
         $requeteStagiaire="select idStagiaire,nom,prenom,Email,nomFiliere,photo,civilite,date_inscription 
                from filiere as f,stagiaire as s
                where f.idFiliere=s.idFiliere
                and (nom like '%$nomPrenom%' or prenom like '%$nomPrenom%')
                and f.idFiliere=$idfiliere
                order by idStagiaire
                limit $size
                offset $offset";
        
        $requeteCount="select count(*) countS from stagiaire
                where (nom like '%$nomPrenom%' or prenom like '%$nomPrenom%')
                and idFiliere=$idfiliere";
    }

    $resultatFiliere=$pdo->query($requeteFiliere);
    $resultatStagiaire=$pdo->query($requeteStagiaire);
    $resultatCount=$pdo->query($requeteCount);

    $tabCount=$resultatCount->fetch();
    $nbrStagiaire=$tabCount['countS'];
    $reste=$nbrStagiaire % $size;   
    if($reste==0) 
        $nbrPage=$nbrStagiaire/$size;   
    else
        $nbrPage=floor($nbrStagiaire/$size)+1;  
?>
<!DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Gestion des stagiaires</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    </head>
    <body>
        <?php require("menu.php"); ?>
        
        <div class="container">
            <div class="panel panel-success margetop60">
                <div class="panel-heading">Rechercher des stagiaires</div>
                <div class="panel-body">
                    <form method="get" action="stagiaires.php" class="form-inline">
                        <div class="form-group">
                            <input type="text" name="nomPrenom" 
                                   placeholder="Nom ou Prénom"
                                   class="form-control"
                                   value="<?php echo $nomPrenom ?>"/>
                        </div>
                        <label for="idfiliere">Filière disponible pour passer le stage :</label>
                        <select name="idfiliere" class="form-control" id="idfiliere"
                                onchange="this.form.submit()">
                            <option value=0>Toutes les filières</option>
                            <?php while ($filiere=$resultatFiliere->fetch()) { ?>
                                <option value="<?php echo $filiere['idFiliere'] ?>"
                                    <?php if($filiere['idFiliere']==$idfiliere) echo "selected" ?>>
                                    <?php echo $filiere['nomFiliere'] ?> 
                                </option>
                            <?php } ?>
                        </select>
                        <input type="submit" class="btn btn-success" value='Chercher... '>
                        <span class="glyphicon glyphicon-search"></span>
                        
                        &nbsp;&nbsp;
                        <?php if ($_SESSION['user']['role']== 'ADMIN') {?>
                            <a href="nouveauStagiaire.php">
                                <i class="fa-solid fa-user-plus"></i>
                                Nouveau Stagiaire
                            </a>
                        <?php }?>
                    </form>
                </div>
            </div>
            
            <div class="panel panel-primary">
                <div class="panel-heading">Liste des Stagiaires (<?php echo $nbrStagiaire ?> Stagiaires)</div>
                <div class="panel-body">
                    <div class="stagiaire-list">
                        <div class="stagiaire-header">
                            <div>Numéro</div>
                            <div>Nom</div>
                            <div>Prénom</div>
                            <div>Email</div>
                            <div>Filière</div>
                            <div>CV</div>
                            <div>date d'inscription</div>
                            <?php if ($_SESSION['user']['role']== 'ADMIN') {?><div>Actions</div><?php }?>
                        </div>
                        <?php while($stagiaire=$resultatStagiaire->fetch()){ ?>
                            <div class="stagiaire-row">
                                <div><?php echo $stagiaire['idStagiaire'] ?></div>
                                <div><?php echo $stagiaire['nom'] ?></div>
                                <div><?php echo $stagiaire['prenom'] ?></div> 
                                <div><?php echo $stagiaire['Email'] ?></div> 
                                <div><?php echo $stagiaire['nomFiliere'] ?></div>
                                
                                <div>
                                    <a href='voir_cv.php?image=<?php echo $stagiaire["photo"]; ?>'>
                                        <img src="../images/<?php echo $stagiaire['photo']?>"
                                        width="100px" height="100px" class="img-circle">
                                    </a> 
                                </div>
                                <div><?php echo $stagiaire['date_inscription'] ?></div>
                                <?php if ($_SESSION['user']['role']== 'ADMIN') {?>
                                    <div class="actions">
                                        <a href="editerStagiaire.php?idS=<?php echo $stagiaire['idStagiaire'] ?>">
                                            <i class="fa-solid fa-pencil-alt fa-lg"></i>
                                        </a>
                                        <a onclick="return confirm('Etes vous sur de vouloir supprimer le stagiaire')"
                                            href="supprimerStagiaire.php?idS=<?php echo $stagiaire['idStagiaire'] ?>">
                                            <i class="fa-solid fa-trash-alt fa-lg"></i>
                                        </a>
                                    </div>
                                <?php }?>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="pagination-container">
                        <ul class="pagination">
                            <?php for($i=1;$i<=$nbrPage;$i++){ ?>
                                <li class="<?php if($i==$page) echo 'active' ?>"> 
                                    <a href="stagiaires.php?page=<?php echo $i;?>&nomPrenom=<?php echo $nomPrenom ?>&idfiliere=<?php echo $idfiliere ?>">
                                        <?php echo $i; ?>
                                    </a> 
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <br><br><br><br><br><br><br><br>
    </body>
    <style>
        .fa-pencil-alt{
            color:lightblue;
        }
        .fa-pencil-alt:hover{
            color:green;
        }
        .fa-trash-alt{
            color:lightblue;
        }
        .fa-trash-alt:hover{
            color:red;
        }
        
        .container {
            width: 80%;
            margin: auto;
        }

        .panel-success {
            margin-top: 60px;
            border: 1px solid #5cb85c;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
        }

        .panel-heading {
            background-color: #5cb85c;
            color: #fff;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .panel-body {
            padding: 20px;
            box-shadow:0px 15px 60px green;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .btn-success {
            background-color: #5cb85c;
            border-color: #4cae4c;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-success:hover {
            background-color: #4cae4c;
            border-color: #4cae4c;
        }

        .stagiaire-list {
            display: flex;
            flex-direction: column;
        }

        .stagiaire-header, .stagiaire-row {
            display: flex;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .stagiaire-header > div, .stagiaire-row > div {
            flex: 1;
            text-align: center;
        }

        .stagiaire-header {
            font-weight: bold;
        }

        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
        }

        .pagination li {
            margin-right: 5px;
        }

        .pagination li a {
            text-decoration: none;
            color: #337ab7;
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .pagination li.active a {
            background-color: #337ab7;
            color: #fff;
        }

        .img-circle {
            border-radius: 50%;
        }

        .actions {
            display: flex;
            justify-content: center;
        }

        .actions a {
            color: #5cb85c;
            margin: 0 5px;
            transition: color 0.3s ease;
        }

        .actions a:hover {
            color: #4cae4c;
        }

        .form-control {
            border-radius: 6px;
            width: 5cm;
            height: 0.8cm;
            font-family: 'Times New Roman';
            background-color: black;
            font-size: 18px;
            color: white;
        }

        .form-control:hover {
            background-color: white;
            color: black;
            border-radius: 8px;
            height: 0.8cm;
            font-size: 18px;
            font-family: 'Times New Roman';
        }

        @media only screen and (max-width: 768px) {
            .container {
                width: 95%;
            }

            .panel-body {
                padding: 10px;
            }

            .stagiaire-header > div, .stagiaire-row > div {
                font-size: 12px;
                padding: 5px 0;
            }

            .btn-success {
                padding: 8px 16px;
            }

            .img-circle {
                width: 50px;
                height: 50px;
            }
        }
        .fa-vcard{
            color: #007bff;
        }
    </style>
</HTML>
