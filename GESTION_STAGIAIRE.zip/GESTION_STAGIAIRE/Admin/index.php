<?php
    header("location:pages/Login.PHP");
?>